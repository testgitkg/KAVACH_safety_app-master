class FriendModel {
  final String name;
  final String phoneNumber;

  FriendModel({
    required this.name,
    required this.phoneNumber,
  });
}
