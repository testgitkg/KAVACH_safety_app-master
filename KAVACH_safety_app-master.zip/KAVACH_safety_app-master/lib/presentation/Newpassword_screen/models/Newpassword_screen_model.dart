// new_password_model.dart

class NewPasswordModel {
  String newPassword = '';
  String confirmPassword = '';

  NewPasswordModel({required this.newPassword, required this.confirmPassword});
}
