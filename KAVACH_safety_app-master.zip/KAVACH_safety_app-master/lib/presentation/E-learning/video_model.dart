class videoModel {
  String? id;
  String? title;
  String? videoUrl;

  videoModel(this.id, this.title, this.videoUrl);

  videoModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    videoUrl = json['videoUrl'];
  }
}
