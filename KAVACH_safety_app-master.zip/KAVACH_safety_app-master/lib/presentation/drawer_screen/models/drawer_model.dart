import 'chipview_item_model.dart';
import '../../../core/app_export.dart';

class DrawerModel {
  List<ChipviewItemModel> chipviewItemList =
      List.generate(8, (index) => ChipviewItemModel());
}
