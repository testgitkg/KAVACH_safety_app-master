import 'package:flutter/material.dart';

class SettingItem {
  final String title;
  final IconData iconData;

  SettingItem({required this.title, required this.iconData});
}
