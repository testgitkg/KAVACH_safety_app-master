// feedback_model.dart

class FeedbackModel {
  final String feedback;
  final String email;

  FeedbackModel({required this.feedback, required this.email});
}
