class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Splash screen images
  static String imgLog61 = '$imagePath/img_log6_1.png';

  // sign up / login images
  static String imgLog62 = '$imagePath/img_log6_2.png';

  static String
      imgVecteezygooglelogoontransparentbackgroundpopularsearchengine292849641 =
      '$imagePath/img_vecteezygooglelogoontransparentbackgroundpopularsearchengine29284964_1.png';

  // password images
  static String imgHidden121978911 = '$imagePath/img_hidden12197891_1.png';

  // drawer images
  static String imgLog6243x57 = '$imagePath/img_log6_2_43x57.png';

  static String imgClose80359091 = '$imagePath/img_close_8035909_1.png';

  static String imgWoman41400471 = '$imagePath/img_woman_4140047_1.png';

  static String imgPencil94400452 = '$imagePath/img_pencil_9440045_2.png';

  static String imgMirroring10054636 = '$imagePath/img_mirroring_10054636.png';

  static String imgInformation1076745 =
      '$imagePath/img_information_1076745.png';

  static String imgText28786711 = '$imagePath/img_text2878671_1.png';

  static String imgRespect11891831 = '$imagePath/img_respect1189183_1.png';

  static String imgDeletelist12011 = '$imagePath/img_deletelist1201_1.png';

  static String imgSocialengagement129435181 =
      '$imagePath/img_socialengagement12943518_1.png';

  static String imgProtected20583241 = '$imagePath/img_protected2058324_1.png';

  static String imgInfo9439331 = '$imagePath/img_info943933_1.png';

  static String imgTranslate64903261 = '$imagePath/img_translate6490326_1.png';

  static String imgSettings4202161 = '$imagePath/img_settings420216_1.png';

  static String imgLogout44003141 = '$imagePath/img_logout_4400314_1.png';

  // profile images
  static String imgWoman41400472 = '$imagePath/img_woman_4140047_2.png';

  static String imgCamera = '$imagePath/img_camera.png';

  static String imgGroup21 = '$imagePath/img_group_21.png';

  // history-Two images
  static String imgWallClock709511 = '$imagePath/img_wall_clock_709511.png';

  static String img29671291 = '$imagePath/img_2967129_1.png';

  // history-Three images
  static String imgSos461710421 = '$imagePath/img_sos_4617104_2_1.png';

  // Common images
  static String imgLog6290x116 = '$imagePath/img_log6_2_90x116.png';

  static String imgRightArrow3682892 = '$imagePath/img_right_arrow_3682892.png';

  static String imgName = '$imagePath/img_name.png';

  static String imgLog6241x57 = '$imagePath/img_log6_2_41x57.png';

  static String imgPngwing1 = '$imagePath/img_pngwing_1.png';

  static String imgPngwing2 = '$imagePath/img_pngwing_2.png';

  static String imgNavTrackMe = '$imagePath/img_nav_track_me.png';

  static String imgTape74759501 = '$imagePath/img_tape_7475950_1.png';

  static String imgSos46171041 = '$imagePath/img_sos_4617104_1.png';

  static String imgPhoneSet9658965 = '$imagePath/img_phone_set_9658965.png';

  static String imgNavHelpline = '$imagePath/img_nav_helpline.png';

  static String imgLeftArrow11819409 = '$imagePath/img_left_arrow_11819409.png';

  static String imgAvatar68342031 = '$imagePath/img_avatar_6834203_1.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
